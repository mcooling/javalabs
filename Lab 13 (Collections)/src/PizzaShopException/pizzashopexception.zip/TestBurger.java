package PizzaShopException;

public class TestBurger 
{

    public static void main(String[] args) 
    
    {
	
	Burger newBurger = new Burger("cheeseburger", new String [] {"cheese", "onions"}, 6.95);
	System.out.println(newBurger.toString());
		
    }

}
